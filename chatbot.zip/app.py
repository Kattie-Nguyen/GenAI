# app.py

# Import necessary libraries
import streamlit as st
from chatbot import get_total_revenue, get_net_income_change, get_total_assets, get_total_liabilities, get_cash_flow

# Streamlit App Layout
st.title("Financial Analysis Chatbot")

st.markdown("""
    This chatbot provides financial insights for Microsoft, Tesla, and Apple for the fiscal years 2022, 2023, and 2024.
    
    You can ask about the following:
    - Total Revenue
    - Net Income Change
    - Total Assets
    - Total Liabilities
    - Cash Flow from Operating Activities
    
    Example Queries:
    - What is the total revenue for Microsoft?
    - How has net income changed over the last year for Tesla?
    - What are the total liabilities of Apple?
    - What are the total assets of [Company]?
    - What is the cash flow from operating activities for [Company]?
   
""")

# User Input
user_query = st.text_input("Ask your financial question:")

# Chatbot Logic
if user_query:
    user_query = user_query.lower()
    
    # Check for Total Revenue Query
    if "total revenue" in user_query:
        for company in ['Microsoft', 'Tesla', 'Apple']:
            if company.lower() in user_query:
                revenue = get_total_revenue(company)
                st.subheader(f"Total Revenue for {company}:")
                st.write(revenue)
                break
    
    # Check for Net Income Change Query
    elif "net income change" in user_query:
        for company in ['Microsoft', 'Tesla', 'Apple']:
            if company.lower() in user_query:
                net_income_change = get_net_income_change(company)
                st.subheader(f"Net Income Change for {company}:")
                st.write(net_income_change)
                break
    
    # Check for Total Assets Query
    elif "total assets" in user_query:
        for company in ['Microsoft', 'Tesla', 'Apple']:
            if company.lower() in user_query:
                assets = get_total_assets(company)
                st.subheader(f"Total Assets for {company}:")
                st.write(assets)
                break
    
    # Check for Total Liabilities Query
    elif "total liabilities" in user_query:
        for company in ['Microsoft', 'Tesla', 'Apple']:
            if company.lower() in user_query:
                liabilities = get_total_liabilities(company)
                st.subheader(f"Total Liabilities for {company}:")
                st.write(liabilities)
                break
    
    # Check for Cash Flow Query
    elif "cash flow" in user_query:
        for company in ['Microsoft', 'Tesla', 'Apple']:
            if company.lower() in user_query:
                cash_flow = get_cash_flow(company)
                st.subheader(f"Cash Flow from Operating Activities for {company}:")
                st.write(cash_flow)
                break
    
    else:
        st.warning("Sorry, I can only provide information on predefined queries.")
